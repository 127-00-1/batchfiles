# Simple-Error-Spam
Just a simple spammer

ripbozo.vbs - spam creates error boxes


loop.bat - spam opens ripbozo.vbs


kill.bat - kills the error boxes


kill two.bat - kills the loop
